package Modelo;

public class Dependencia {
    private String idDependencia;
    private String nombre;
    private String descripcion;

    public Dependencia(String idDependencia, String nombre, String descripcion) {
        this.idDependencia = idDependencia;
        this.nombre = nombre;
        this.descripcion = descripcion;
    }

    public String getIdDependencia() {
        return idDependencia;
    }

    public void setIdDependencia(String idDependencia) {
        this.idDependencia = idDependencia;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
