
package Modelo;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class Tramite {
    //Atributos
    private int codTra;
    private int prioridad;
    private Alumno User;
    private String asunto;
    private Dependencia dependencia;
    private LocalDateTime horaInicio;
    private LocalDateTime horaFinal;
    private String Documento;
    //Constructores
    
    public Tramite() {
        this.codTra = 0;
        this.prioridad = 0;
        this.asunto = "";
        this.User = null;
        this.dependencia = null;
        
    }

    public Tramite(int codTra, int prioridad, Alumno User, String asunto, Dependencia dependencia,LocalDateTime horaFinal) {
        this.horaInicio=horaFinal;
        this.horaInicio=LocalDateTime.now();
        this.codTra = codTra;
        this.prioridad = prioridad;
        this.User = User;
        this.asunto = asunto;
        this.dependencia = dependencia;
    }
    
    
    public int getCodTra() {
        return codTra;
    }

    public void setCodTra(int codTra) {
        this.codTra = codTra;
    }

    public int getPrioridad() {
        return prioridad;
    }

    public void setPrioridad(int prioridad) {
        this.prioridad = prioridad;
    }

    public Alumno getUser() {
        return User;
    }

    public void setUser(Alumno User) {
        this.User = User;
    }

    public String getAsunto() {
        return asunto;
    }

    public void setAsunto(String asunto) {
        this.asunto = asunto;
    }

    public Dependencia getDependencia() {
        return dependencia;
    }

    //Get And Set
    public void setDependencia(Dependencia dependencia) {    
        this.dependencia = dependencia;
    } 

    public LocalDateTime getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(LocalDateTime horaInicio) {
        this.horaInicio = horaInicio;
    }

    public LocalDateTime getHoraFinal() {
        return horaFinal;
    }

    public void setHoraFinal(LocalDateTime horaFinal) {
        this.horaFinal = horaFinal;
    }

    public String getDocumento() {
        return Documento;
    }

    public void setDocumento(String Documento) {
        this.Documento = Documento;
    }
    
}
