
package Modelo;


public class RegistrarAlumno {
    
}
