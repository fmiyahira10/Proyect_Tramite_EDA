
package Modelo;

import java.util.Scanner;

public abstract class Persona {
    
    protected int dni;
    protected String nombre;
    protected int telefono;
    protected String email;

    public Persona(int dni, String nombre, int telefono, String email) {
        this.dni = dni;
        this.nombre = nombre;
        this.telefono = telefono;
        this.email = email;
    }
    
    public int getDni() {
        return dni;
    }

    public void setDni(int dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
     public void leer(){
        Scanner lector = new Scanner(System.in);
        System.out.println("Ingrese la informacion de la Persona: ");
        System.out.print("Ingrese el DNI: ");
        this.dni = lector.nextInt();
        System.out.println("Ingrese los nombres: ");
        lector.nextLine();
        this.nombre = lector.nextLine();
        System.out.print("Ingrese el email: ");
        this.email = lector.nextLine();
        System.out.print("Ingrese el telefono: ");
        this.telefono = lector.nextInt();
    }
    public String verDatos(){
        return this.dni + "\t" + this.nombre + "\t"+
                getEmail();
    }
  
}
