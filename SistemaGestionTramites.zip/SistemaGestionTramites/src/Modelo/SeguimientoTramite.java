
package Modelo;

public class SeguimientoTramite {
    
}
