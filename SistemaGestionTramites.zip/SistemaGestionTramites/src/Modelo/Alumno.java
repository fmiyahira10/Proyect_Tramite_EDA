package Modelo;
public class Alumno extends Persona{
    // Atributos
    private int codAlumno;
    private String contra;
    private String cp; // Carrera profesional    
    // Metodos

    public Alumno(int dni, String nombres, int telefono, String email) {
        super(dni, nombres, telefono, email);
        this.codAlumno = 0;
        this.cp = "";        
    }

    public Alumno(int dni, String nombres, int telefono, String email, int codAlumno, String cp, String contra) {
        super(dni, nombres, telefono, email);
        this.codAlumno = codAlumno;
        this.cp = cp;
        this.contra=contra;
    }
    // Getter and Setter

    public int getCodAlumno() {
        return codAlumno;
    }

    public void setCodAlumno(int codAlumno) {
        this.codAlumno = codAlumno;
    }

    public String getCp() {
        return cp;
    }

    public void setCp(String cp) {
        this.cp = cp;
    }
    
    @Override
    public String verDatos(){
        return super.verDatos() + "\t" +
                this.codAlumno + "\t" +
                this.cp;
    }

    public String getContra() {
        return contra;
    }

    public void setContra(String contra) {
        this.contra = contra;
    }
    
}
