/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controladores;
import Vista.*;
/**
 *
 * @author Usuario
 */
public class AdminController {
    public static Admin ventana = new Admin();
        public static void Mostrar(){
            ventana.setVisible(true);
        }
        public static void Ocultar(){
            ventana.setVisible(false);
        }
        public static void BtLogout(){
            Ocultar();
            LoginController.Mostrar();
        }
    
    
    
}
