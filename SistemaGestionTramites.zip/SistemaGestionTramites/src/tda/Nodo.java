package tda;

import Modelo.Alumno;

public class Nodo<T> {
    // Atributos
    private Alumno alumno;
    private Nodo sgteNodo;
    // Constructores
    public Nodo(){
        alumno = null;
        sgteNodo = null;
    }
    public Nodo(Alumno alumno, Nodo pSgteNodo){
        this.alumno = alumno;
        sgteNodo = pSgteNodo;
    }
    // Getter and Setter

    public Alumno getAlumno() {
        return alumno;
    }

    public void setAlumno(Alumno alumno) {
        this.alumno = alumno;
    }

    public void setSgteNodo(Nodo pSgteNodo){
        sgteNodo = pSgteNodo;
    }
    public Nodo getSgteNodo(){
        return sgteNodo;
    }
}
